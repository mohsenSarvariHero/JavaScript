const data = [
  {
    username: "user1",
    credit: 15000,
    id: 0,
  },
  {
    username: "user2",
    credit: 10000,
    id: 1,
  },
  {
    username: "user3",
    credit: 25000,
    id: 2,
  },
  {
    username: "user4",
    credit: 98000,
    id: 3,
  },
  {
    username: "user5",
    credit: 72000,
    id: 4,
  },
  {
    username: "user6",
    credit: 46500,
    id: 5,
  },
  {
    username: "user7",
    credit: 16500,
    id: 6,
  },
  {
    username: "user8",
    credit: 56000,
    id: 7,
  },
  {
    username: "user9",
    credit: 11230,
    id: 8,
  },
  {
    username: "user10",
    credit: 60500,
    id: 9,
  },
  {
    username: "user11",
    credit: 85000,
    id: 10,
  },
];
