/*

switch(x) {
  case 'value1':  // if (x === 'value1')
    ...
    [break]

  case 'value2':  // if (x === 'value2')
    ...
    [break]

  default:
    ...
    [break]
}
*/

// let browser = "Opera";
// switch (browser) {
//   case 'Edge':
//     console.log( "You've got the Edge!" );
//     break;
//   case 'Chrome':
//   case 'Firefox':
//   case 'Safari':
//   case 'Opera':
//     console.log( 'Okay we support these browsers too' );
//     break;

//   default:
//     console.log( 'We hope that this page looks ok!' );
// }

let numStr = "1"

switch (numStr) {
  case 1:
    console.log("is equal to 1");
    break;
  default:
    console.log("it is not 1");
}
