
let whileCondition = 0;

while( 0 < whileCondition && whileCondition < 10){
    console.log(whileCondition);
    whileCondition += 1;
}

whileCondition = 0;
console.log("------------------");

do{
    console.log(whileCondition);
    whileCondition += 1; 
}while(0 < whileCondition && whileCondition < 10)
