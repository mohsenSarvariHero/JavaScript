let expression;



if(expression){

}
else if (expression){
    
}
/// else if ...
else {
    
}


if("2" > "12"){
    console.log(true);
}
