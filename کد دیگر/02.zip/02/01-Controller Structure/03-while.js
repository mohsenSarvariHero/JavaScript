let expression;

while(expression) {

}


do {

}while(expression)
