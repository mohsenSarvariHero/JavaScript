let expression;


let age = 18;
let isOld = age > 50 ? "old" : "young";

console.log(isOld);