
let fun1 = function( a  , b) {
    console.log("hello from fun1");
    
}


let fun2 = fun1
fun1();

fun2()










