function fun1() {

    return 10
}

// console.log(fun1());

function isOdd(a) {
    if (a == 0)
        return

}

function fun2() {
    // code 
    if (cond1) {
        return 1
    }
    else {
        return 2
    }
}

function fun3() {
    return 5
    5 * 10;
}

function fun4(a) {
    a = 10;
    return a
}


let a = 5;
// console.log(fun4(a));
// console.log(a);

function sum(a, b) {
    
    b = b ?? 2

    return a + b;
}

// console.log(sum(5 , 0 ));


function sum2(a=0, b , ...c) {
    
    console.log(a , b , c);
}

sum2( 1 ,2  ,3,4,5,6,7,8)



