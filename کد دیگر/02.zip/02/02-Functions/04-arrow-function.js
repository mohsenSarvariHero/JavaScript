let sum = (a, b) => {
    // code
    return a + b;

}

let sum = (a, b) => a + b;

console.log(sum(5, 2));