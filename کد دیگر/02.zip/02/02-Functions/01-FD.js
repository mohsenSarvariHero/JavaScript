

let i = 5;

function fun1(a , b){
    let i = 10;
    return a + b; 
}



// console.log(fun1(10 , 50));

fun1(10 , 50);

console.log(i);


