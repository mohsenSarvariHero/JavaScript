
// let i = 5;
// function fun1() {
    

    
//     let i = 5
//     function fun2 () {
//         // console.log(i);

//         fun3()
//     }
    

    
//     fun2();
// }


// function fun3() {
//     console.log(i);
// }


// fun1();

// function test() {
//     if(true){
//         let i = 15;
//     }
//     console.log(i);
// }


// test()

function fun1() {
    let fun2 =  function() {
        var x = 1;
        
    }


    function fun3() {
        console.log(x);
    }


    fun2();
    fun3();
}


fun1();




