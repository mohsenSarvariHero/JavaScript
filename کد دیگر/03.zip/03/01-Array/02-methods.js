let arr1 = ['apple', 'benana', 'orange', 'watermelone']

let arr2 = [1, 2, 3, 4, 6]


// console.log(arr1.toString());
// console.log(arr2.toString());


// console.log(arr1 === arr3);

// delete arr2[0]

// console.log(arr2)

// console.log(arr1);
// console.log('----------------------');

// let a = arr1.splice(0)

// console.log(arr1);
// console.log(a);

// let c = arr1.splice(0 , 2 , 'kiwi' , 'item');

// console.log(c);
// console.log(arr1.slice(1 , 2));
// console.log(arr1);

// console.log(arr1.concat(...arr2));
let obj1 = {
    name: '1part1',
    id: 1
}
let obj2 = {
    name: '4part2',
    id: 5
}
let obj3 = {
    name: '2part3',
    id: 2,
}


let arr3 = [obj1, obj2, obj3]


// let b = a.slice(0 , 1)
// console.log(a);
// console.log(b);
// b[0].name = 'part111'
// console.log(a);
// console.log(b);

// function print(i){
//     console.log(i);
// }



// arr1.forEach((element , index , array)=>{
//     // console.log(element , index , array);
//     if(index == array.length - 1)
//         print(element)
// })

// arr1.forEach()


// console.log(arr1.indexOf('apple'));
// console.log(arr1.includes('apple'));

// console.log(arr3.includes({
//     name: 'part3'
// }));

// let b = arr3.findIndex((element) => {
//     return element.name == 'part3'
// })
// console.log(b);

// let result = arr2.filter((elemet) =>
//     elemet % 2 == 0
// )
// console.log(arr2);
// console.log(result);


// let result = arr2.map((element)=>{
//     return 0;
// })

// console.log(arr2);
// console.log(result);


let arr5 = [1,5,3,10,0]
let arr6 = ['پارت'  , 
'ابر' ,
'حرف']
// console.log(arr5.sort());
// console.log(arr5);

// arr3.sort((a , b)=>{
//     return a      
// })

// arr6.sort((a , b)=>{
//     return a.localeCompare(b)
// })

// console.log(arr6);


// console.log(arr1.reverse());
// console.log(arr1);

// let str = 'hello from part'
// let splitStr = str.split(' ');

// console.log(splitStr.join("     "));

