const arr1 = [1 , 'hello' , function() {
    console.log('hello');
} , 1]

const arr2 = Array();
// arr1[2]();

let numbers = [1,2,3,4,5,6,7,8];


let b = numbers.pop();
// console.log(b , numbers);

numbers.push(b)

// console.log(b , numbers);

// let c = numbers.shift();

// console.log(c , numbers);

let queue = []

queue.push(1)
queue.push(3)
queue.push(2)

// console.log(queue);

// let var1 = queue.shift()

// numbers.unshift(0)

// console.log(numbers);


let arr3 = []

arr3[20] = 1

// console.log(arr3.length);

// for(let i = 0 ; i < numbers.length ; i++){
//     console.log(numbers[i]);
// }

// for(let i in numbers){
//     console.log(i);
// }

// console.log(numbers.length);

// numbers.length = 2;

// console.log(numbers);

// numbers.length = 10;

// console.log(numbers);

//  

// [1,2,3,4]

// [3,4,1,2]


