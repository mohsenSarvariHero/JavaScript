import { multiply } from './file1.js';
export function square(x) {
    return multiply(x, x)
}