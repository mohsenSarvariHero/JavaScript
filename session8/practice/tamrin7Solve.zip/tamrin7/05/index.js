'use strict'
// Only change code below this line
import { multiply } from './some-modules/file1.js';
import { square } from './some-modules/file2.js';
import { isRightTriangle } from './some-modules/file3.js';

console.log(isRightTriangle(3, 4, 5));
console.log(isRightTriangle(4, 4, 5));