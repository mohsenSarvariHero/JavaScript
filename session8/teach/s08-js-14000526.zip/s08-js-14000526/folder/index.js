// import { obj,obj1 ,multiply } from './aaa/module1.js'

// https://javascript.info/modules-intro
// console.log('aaaa', obj);
// console.log('aaaa', obj1);

// console.log(multiply(5,6));


import obj from './aaa/module1.js'

console.log(obj);