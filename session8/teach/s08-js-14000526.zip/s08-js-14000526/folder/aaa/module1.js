export const obj = {
    name: 'alireza'
}

const obj1 = {
    ioio: 0
}

const multiply = (x, y) => { return x * y }

export function something(){

}

const obj0 = {imDefault000: true}

export default obj0;

export { obj1, multiply }


