let arr1 = [1, 2, 3, 4];
let arr2 = [3, 4, 5, 6];





function sim(arr1, arr2) {
    const final = [];
    arr1.foreach((e1) => arr2.foreach((e2) => {
        if (e1 == e2) {
            final.push(e1)
        }
    }));

}